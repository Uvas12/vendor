<?php

namespace Liuggio\StatsdClient\Exception;

class InvalidArgumentException extends \InvalidArgumentException
{
}
