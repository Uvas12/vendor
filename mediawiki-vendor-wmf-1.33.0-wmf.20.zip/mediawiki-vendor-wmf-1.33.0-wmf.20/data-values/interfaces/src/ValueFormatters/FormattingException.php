<?php

namespace ValueFormatters;

use RuntimeException;

/**
 * @since 0.1.3
 *
 * @license GPL-2.0+
 * @author Jeroen De Dauw < jeroendedauw@gmail.com >
 */
class FormattingException extends RuntimeException {

}
