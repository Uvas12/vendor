<?php

namespace DataValues;

use InvalidArgumentException;

/**
 * @since 0.1
 *
 * @license GPL-2.0+
 * @author Daniel Kinzler
 */
class IllegalValueException extends InvalidArgumentException {

}
