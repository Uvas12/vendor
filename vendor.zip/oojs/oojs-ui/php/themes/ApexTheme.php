<?php

namespace OOUI;

class ApexTheme extends Theme {
}
