<?php

namespace OOUI;

class Exception extends \Exception {
}
