<?php


$loader = require_once __DIR__ . "/../vendor/autoload.php";
$loader->add('Liuggio\\', __DIR__);