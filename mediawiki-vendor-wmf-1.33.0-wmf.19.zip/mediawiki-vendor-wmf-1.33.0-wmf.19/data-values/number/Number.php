<?php

if ( defined( 'DATAVALUES_NUMBER_VERSION' ) ) {
	// Do not initialize more than once.
	return 1;
}

define( 'DATAVALUES_NUMBER_VERSION', '0.10.1' );
